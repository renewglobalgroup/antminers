REQUIRE_IMAGE_METADATA=1

RAMFS_COPY_BIN="/bin/busybox:/bin/ln:/bin/sed:/bin/gzip:/usr/bin/head:/usr/bin/tail:/usr/bin/xargs"
RAMFS_COPY_BIN="$RAMFS_COPY_BIN /usr/sbin/nanddump"
RAMFS_COPY_BIN="$RAMFS_COPY_BIN /usr/sbin/fw_printenv"
RAMFS_COPY_BIN="$RAMFS_COPY_BIN /usr/sbin/fw_printenv:/usr/sbin/fw_setenv"

RAMFS_COPY_DATA="/etc/fw_env.config /var/lock/fw_printenv.lock"

zynq_write_if_different() {
	local tar_file=$1
	local file_name=$2
	local mtd_name=$3
	local msg=$4
	local board_name="$(nand_board_name)"

	local file_path=sysupgrade-$board_name/$file_name
	local file_length=`(tar xf ${tar_file} $file_path -O | wc -c) 2>/dev/null`

	[ "$file_length" != 0 ] || return 2

	local tmp_file="/tmp/$file_name"
	tar xf ${tar_file} $file_path -O > "$tmp_file"

	local result=0
	if [ $(mtd verify "$tmp_file" ${mtd_name} 2>&1 1>/dev/null | tail -n 1) != "Success" ];	then
		echo "Upgrading $msg..."
		mtd erase ${mtd_name}
		mtd write "$tmp_file" ${mtd_name}
	else
		echo "Skipping upgrade of $msg..."
		result=1
	fi

	rm "$tmp_file"
	return $result
}

zynq_write_to_dst() {
	local tar_file=$1
	local file_name=$2
	local dst_path=$3
	local msg=$4
	local board_name="$(nand_board_name)"

	local file_path=sysupgrade-$board_name/$file_name
	local file_length=`(tar xf ${tar_file} $file_path -O | wc -c) 2>/dev/null`

	[ "$file_length" != 0 ] || return 2

	echo "Upgrading $msg..."
	tar xf ${tar_file} $file_path -O > "$dst_path" || return 1

	return 0
}

zynq_write_uenv() {
	local tar_file=$1
	local board_name="$(nand_board_name)"

	local file_path=sysupgrade-$board_name/uenv
	local uenv_length=`(tar xf ${tar_file} $file_path -O | wc -c) 2>/dev/null`

	[ "$uenv_length" != 0 ] && {
		echo "Upgrading U-Boot default environment..."
		tar xf ${tar_file} $file_path -O | fw_setenv --script -
		fw_printenv
	}
}

zynq_write_spl() {
	local tar_file=$1

	zynq_write_if_different ${tar_file} spl boot "SPL"
}

zynq_write_uboot() {
	local tar_file=$1
	local board_name="$(nand_board_name)"

	zynq_write_if_different ${tar_file} uboot uboot "U-Boot" || return 0
	# it is also needed to upgrade U-Boot enviroment when U-Boot has been upgraded
	zynq_write_uenv ${tar_file}
}

zynq_write_fpga_partition() {
	local tar_file=$1
	local cur_partition_name="fpga$2"
	local dst_partition_name="fpga$3"

	zynq_write_if_different ${tar_file} fpga ${dst_partition_name} "FPGA bitstream"
	local result=$?
	if [ $result -eq 2 ]; then
		local cur_mtd="/dev/mtd$(($2 + 1))"
		local cur_fpga="/tmp/cur_fpga.bin"

		# dump current FPGA bitstream and compare it with destination one
		# copy current partition to destination one only if it differs
		nanddump ${cur_mtd} > "$cur_fpga"
		[ $(mtd verify "$cur_fpga" ${dst_partition_name} 2>&1 1>/dev/null | tail -n 1) != "Success" ] && {
			echo "Upgrading FPGA bitstream with current one..."
			mtd erase ${dst_partition_name}
			mtd write "$cur_fpga" ${dst_partition_name}
		}
		rm "$cur_fpga"
	fi
}

zynq_get_firmware_partition() {
	local dst_firmware=$1
	local partition_name="firmware$1"

	fw_setenv --script - <<-EOF
		# remove factory reset to prevent collision with upgrade
		factory_reset
		#
		# boot after upgrade is treated as a first one; this prevents interference
		# with inserted SD card where uEnv.txt can hinder the upgrade process
		first_boot yes
		#
		# set upgrade stage to 0 to inform U-Boot that upgrade process has been
		# started; when first boot after upgrade is not successful then U-Boot
		# reverts firmware to previous one
		upgrade_stage 0
		#
		# switch to new firmware in environment
		firmware ${dst_firmware}
	EOF

	echo "$partition_name"
}

zynq_command_check_image() {
	# check if sysupgrade.tar contains COMMAND script with check_image function
	# and run it; this function can be used for checking target environment and
	# refuse upgrade when the firmware is not compatible
	local args="$1"
	local board_name="$(cat /tmp/sysinfo/board_name)"
	local command_file="/tmp/sysupgrade-COMMAND"

	local command_path=sysupgrade-$board_name/COMMAND
	local command_length=`(get_image "$args" | tar xf - $command_path -O | wc -c) 2> /dev/null`

	[ "$command_length" != 0 ] && {
		get_image "$args" | tar xf - $command_path -O > "$command_file"
		source "$command_file"
		if type 'check_image' >/dev/null 2>/dev/null; then
			check_image "$board_name" "$args" || return 1
		fi
	}

	return 0
}

zynq_command_pre_upgrade() {
	# check if sysupgrade.tar contains COMMAND script with pre_upgrade function
	# and run it; this function can be used for fixing NAND U-Boot environment
	# variables or upgrading nonstandard partitions like SPL
	local tar_file=$1
	local board_name="$(nand_board_name)"
	local command_file="/tmp/sysupgrade-COMMAND"

	local command_path=sysupgrade-$board_name/COMMAND
	local command_length=`(tar xf ${tar_file} $command_path -O | wc -c) 2> /dev/null`

	[ "$command_length" != 0 ] && {
		tar xf ${tar_file} $command_path -O > "$command_file"
		source "$command_file"
		if type 'pre_upgrade' >/dev/null 2>/dev/null; then
			pre_upgrade "$board_name" "$tar_file"
		fi
	}
}

firmware_check_signature() {
	# signature is stored at the end of the firmware image
	if ! fwtool -q -s /tmp/sysupgrade.sig "$1"; then
		echo "Image signature not found"
		return 1
	fi

	# the last 4 bytes contains size of signature
	local image_size=$((0x$(get_image "$1" | tail -c 4 | hexdump -v -n 4 -e '1/1 "%02x"')))
	local image_digest=$(get_image "$1" | head -c -${image_size} | sha256sum | awk '{print $1}')

	# check signature of image digest without signature metadata
	if ! echo -n "$image_digest" | usign -V -q -m - -x "/tmp/sysupgrade.sig" -P "/etc/opkg/keys"; then
		echo "Invalid image signature"
		return 1
	fi
}

firmware_check_format() {
	. /usr/share/libubox/jshn.sh

	json_load "$(cat $1)" || {
		echo "Invalid image metadata"
		return 1
	}

	# get image format version
	json_get_vars format_version || return 1
	# get compatible BOS mode
	json_get_vars bos_mode
	# if not set then it is old firmware compatible only with NAND
	bos_mode=${bos_mode:-nand}

	json_load "$(cat /etc/fw_info.json)" || {
		echo "Invalid firmware info"
		return 1
	}

	if [ "$bos_mode" != "$(cat "/etc/bos_mode" 2>/dev/null)" ]; then
		echo "Image can be used only in '$bos_mode' mode"
		return 1
	fi

	json_select supported_formats || return 1

	json_get_keys format_keys
	for k in $format_keys; do
		json_get_var supported_format "$k"
		[ "$format_version" = "$supported_format" ] && return 0
	done

	echo "Image format '$format_version' not supported by this firmware"
	echo -n "Supported formats:"
	for k in $format_keys; do
		json_get_var supported_format "$k"
		echo -n " $supported_format"
	done
	echo
}

platform_check_image() {
	[ "$#" -gt 1 ] && return 1

	get_image "$1" | tar -tf - >/dev/null || {
		echo "Invalid image type"
		return 1
	}

	firmware_check_signature "$1" || return 1

	if fwtool -q -i /tmp/sysupgrade.meta "$1"; then
		firmware_check_format "/tmp/sysupgrade.meta" || return 1
	fi

	zynq_command_check_image "$1" || return 1
}

platform_pre_upgrade() {
	local bos_mode=$(cat "/etc/bos_mode" 2>/dev/null)
	# preserve bos_mode after switching to ramdisk
	cp "/etc/bos_mode" "/tmp/" 2>/dev/null

	if [ "${bos_mode:-nand}" == "nand" ]; then
		nand_do_upgrade "$1"
	else
		umount /dev/mmcblk0p1
		umount /dev/mmcblk0p2

		# use NAND upgrade process with redirection to 'platform_do_upgrade'
		# it is Braiins hack to solve problem with ssh sysupgrade where
		# standard platform upgrade is not run in background and termination
		# of ssh daemon effectively ends the SD sysupgrade
		touch "/tmp/platform_upgrade"
		nand_do_upgrade "$1"
	fi
}

platform_nand_pre_upgrade() {
	local cur_firmware=$(fw_printenv -n firmware)
	local dst_firmware=$(($cur_firmware % 2 + 1))

	zynq_command_pre_upgrade "$1"
	zynq_write_spl "$1"
	zynq_write_uboot "$1"

	zynq_write_fpga_partition "$1" ${cur_firmware} ${dst_firmware}
	CI_UBIPART="$(zynq_get_firmware_partition ${dst_firmware})"

	echo "Switching to ${CI_UBIPART}..."
	sync
}

platform_do_upgrade() {
	local tar_file=$1
	local conf_tar="/tmp/sysupgrade.tgz"
	local boot_path="/tmp/mmcblk0p1"
	local overlay_path="/tmp/mmcblk0p2"

	zynq_command_pre_upgrade "${tar_file}"

	mkdir -p "$boot_path" "$overlay_path/upper" || return 1

	mount /dev/mmcblk0p1 "$boot_path" || return 1
	mount /dev/mmcblk0p2 "$overlay_path"

	# remove everything except 'root' directory
	(cd "$overlay_path/upper" 2>/dev/null && ls -1 | grep -v 'root' | xargs -r rm -rf)

	# configuration file backup will be restored during boot
	[ -f "$conf_tar" ] && cp "$conf_tar" "$overlay_path/upper"

	zynq_write_to_dst "${tar_file}" spl "$boot_path/boot.bin" "SPL"
	zynq_write_to_dst "${tar_file}" uboot "$boot_path/u-boot.img" "U-Boot"
	zynq_write_to_dst "${tar_file}" fpga "$boot_path/system.bit.gz" "FPGA bitstream"
	zynq_write_to_dst "${tar_file}" fit "$boot_path/fit.itb" "FIT image"

	# write U-Boot image without header to partition 3 for special boot mode
	[ -b  /dev/mmcblk0p3 -a "$(cat /sys/class/block/mmcblk0p3/size 2>/dev/null)" == 2048 ] && {
		dd if="$boot_path/u-boot.img" of=/dev/mmcblk0p3 ibs=1 skip=64
	}
	sync
}
