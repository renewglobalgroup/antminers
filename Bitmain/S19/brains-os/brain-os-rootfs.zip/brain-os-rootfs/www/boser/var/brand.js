window.BRAND = {
    name: 'Braiins OS+\u200E',
    logo: {
        header: { src: '/var/header.svg', style: { padding: 14 } },
        footer: { src: '/var/footer.svg', style: null },
    },
    copy: {
        poweredBy: 'Powered by Braiins OS+\u200E for Slush Pool',
        footerSubtitle: null,
    },
    links: {
        products: [
            {
                href: 'https://braiins.com/?utm_source=SlushPool&utm_medium=Header',
                text: 'Braiins.com',
            },
            {
                href: 'https://slushpool.com/?utm_source=SlushPool&utm_medium=Header',
                text: 'Slush Pool',
            },
            {
                href: 'https://braiins-os.com/plus?utm_source=SlushPool&utm_medium=Header',
                text: 'Braiins\xa0OS+\u200E',
                isActive: true,
            },
            {
                href: 'https://braiins.com/farm-proxy?utm_source=SlushPool&utm_medium=Header',
                text: 'Farm Proxy',
            },
            {
                href: 'https://stratumprotocol.org/?utm_source=SlushPool&utm_medium=Header',
                text: 'Stratum V2',
            },
            {
                href: 'https://insights.braiins.com/?utm_source=SlushPool&utm_medium=Header',
                text: 'Mining Insights',
            },
        ],
        documentation: 'https://docs.braiins.com/os/',
        supportTicket: 'https://help.slushpool.com/support/tickets/new',
        supportEmail: 'help@slushpool.com',
    },
    // mode: 'Next',
};
